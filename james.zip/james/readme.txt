February/18/2016: Released version 1.0
	-	You need read instruction in documentation folder
	
08/July/2016: Updated to version 1.1
	- Updated the WooCommerce template files for 2.6.1 version
	- Updated css for new WooCommerce 2.6.1
	-------------------------------
	Updated details:
		- Updated "class-tgm-plugin-activation.php"
		- Updated "less/woocommerce.less"
		- Updated "less/responsive.less"
		- Updated "functions.php"
		- Updated "woocommerce/archive-product.php"
		- Updated "woocommerce/content-product.php"
		- Updated "woocommerce/content-product-archive.php"
		- Updated "woocommerce/content-product_cat.php"
		- Updated "woocommerce/cart/mini-cart.php"
		- Updated "woocommerce/checkout/thankyou.php"
		
		- Removed "woocommerce/myaccount/form-login.php"
		- Removed "woocommerce/myaccount/form-lost-password.php"
		- Removed "woocommerce/myaccount/my-address.php"
		- Removed "woocommerce/myaccount/view-order.php"
	-------------------------------
	
16/July/2016: Updated to version 1.2
	- Fixed add to cart script
	-------------------------------
	Updated details:
		- Updated "theme.js"
		- Updated "include/wooajax.php"
	-------------------------------
	
24/August/2016: Updated to version 1.2.1
	- Fixed quick view arrows
	-------------------------------
	Updated details:
		- Updated "theme.js"
	-------------------------------